import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { Plus, Trash2, Save, History } from 'lucide-react';
import { motion } from 'motion/react';

export const SettingsView: React.FC = () => {
  const { items, addItem, updateItemPrice, updateItemVendor, deleteItem, resetAllData } = useStore();
  const [newItemName, setNewItemName] = useState('');
  const [newItemPrice, setNewItemPrice] = useState('');

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (newItemName && newItemPrice) {
      addItem(newItemName, Number(newItemPrice));
      setNewItemName('');
      setNewItemPrice('');
    }
  };

  return (
    <div className="space-y-8 pb-24">
      <header>
        <h2 className="text-2xl font-bold text-gray-900">Settings</h2>
        <p className="text-sm text-gray-500 mt-1">Manage your items, prices, and vendor details.</p>
      </header>

      {/* Add New Item */}
      <section className="rounded-3xl border border-gray-100 bg-white p-6 shadow-sm">
        <h3 className="mb-4 text-sm font-bold uppercase tracking-widest text-gray-400">Add New Item</h3>
        <form onSubmit={handleAddItem} className="space-y-4">
          <div className="space-y-1">
            <label className="text-xs font-bold text-gray-500 ml-1">Item Name</label>
            <input
              type="text"
              value={newItemName}
              onChange={(e) => setNewItemName(e.target.value)}
              placeholder="e.g. Bread"
              className="w-full rounded-xl border border-gray-200 bg-gray-50 px-4 py-3 text-sm focus:border-blue-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-bold text-gray-500 ml-1">Price per Unit</label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-xs">₹</span>
              <input
                type="number"
                step="0.01"
                value={newItemPrice}
                onChange={(e) => setNewItemPrice(e.target.value)}
                placeholder="0.00"
                className="w-full rounded-xl border border-gray-200 bg-gray-50 py-3 pl-6 pr-3 text-sm focus:border-blue-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              />
            </div>
          </div>
          <button
            type="submit"
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-gray-900 py-3 text-sm font-bold text-white transition-all active:scale-95"
          >
            <Plus size={18} />
            Add Item
          </button>
        </form>
      </section>

      {/* Existing Items */}
      <section className="space-y-6">
        <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400">Manage Items & Vendors</h3>
        <div className="grid gap-6">
          {items.map((item) => (
            <div key={item.id} className="rounded-3xl border border-gray-100 bg-white p-6 shadow-sm space-y-6 relative group">
              <button
                onClick={() => {
                  if (window.confirm(`Are you sure you want to delete ${item.name}? This will remove all delivery history for this item.`)) {
                    deleteItem(item.id);
                  }
                }}
                className="absolute top-4 right-4 p-2 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"
              >
                <Trash2 size={18} />
              </button>

              <div className="flex items-center justify-between pr-8">
                <span className="text-lg font-bold text-gray-900">{item.name}</span>
                <div className="flex items-center gap-1 text-[10px] font-bold text-blue-600 uppercase bg-blue-50 px-2 py-1 rounded-md">
                  <History size={12} />
                  {item.priceHistory.length} Price Points
                </div>
              </div>
              
              {/* Price Update */}
              <div className="flex items-end gap-3">
                <div className="flex-1 space-y-1">
                  <label className="text-[10px] font-bold text-gray-400 ml-1 uppercase tracking-wider">Current Price</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-xs">₹</span>
                    <input
                      type="number"
                      step="0.01"
                      defaultValue={item.priceHistory[item.priceHistory.length - 1].price}
                      onBlur={(e) => {
                        const newPrice = Number(e.target.value);
                        if (newPrice !== item.priceHistory[item.priceHistory.length - 1].price) {
                          updateItemPrice(item.id, newPrice);
                        }
                      }}
                      className="w-full rounded-xl border border-gray-200 bg-gray-50 py-2.5 pl-6 pr-3 text-sm focus:border-blue-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    />
                  </div>
                </div>
                <div className="rounded-xl bg-blue-50 p-2.5 text-blue-600">
                  <Save size={20} />
                </div>
              </div>

              {/* Vendor Details */}
              <div className="space-y-4 pt-4 border-t border-gray-50">
                <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
                  Vendor Details
                </h4>
                <div className="grid gap-3">
                  <input
                    type="text"
                    placeholder="Vendor Name"
                    defaultValue={item.vendor?.name}
                    onBlur={(e) => updateItemVendor(item.id, { ...item.vendor!, name: e.target.value })}
                    className="w-full rounded-xl border border-gray-100 bg-gray-50 px-4 py-2 text-sm focus:border-blue-500 focus:bg-white focus:outline-none"
                  />
                  <input
                    type="text"
                    placeholder="Vendor Phone"
                    defaultValue={item.vendor?.phone}
                    onBlur={(e) => updateItemVendor(item.id, { ...item.vendor!, phone: e.target.value })}
                    className="w-full rounded-xl border border-gray-100 bg-gray-50 px-4 py-2 text-sm focus:border-blue-500 focus:bg-white focus:outline-none"
                  />
                  <textarea
                    placeholder="Vendor Address"
                    defaultValue={item.vendor?.address}
                    onBlur={(e) => updateItemVendor(item.id, { ...item.vendor!, address: e.target.value })}
                    className="w-full rounded-xl border border-gray-100 bg-gray-50 px-4 py-2 text-sm focus:border-blue-500 focus:bg-white focus:outline-none resize-none"
                    rows={2}
                  />
                </div>
              </div>
              
              <p className="text-[10px] text-gray-400 italic">
                * Price changes are tracked historically. Vendor details are for your reference.
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Danger Zone */}
      <section className="pt-8 border-t border-red-50">
        <h3 className="text-sm font-bold uppercase tracking-widest text-red-400 mb-4">Danger Zone</h3>
        <button
          onClick={() => {
            if (window.confirm('Are you sure you want to clear ALL data? This will reset the app and delete all history, items, and notes. This action cannot be undone.')) {
              resetAllData();
            }
          }}
          className="flex w-full items-center justify-center gap-2 rounded-2xl border-2 border-red-100 py-4 text-sm font-bold text-red-500 hover:bg-red-50 transition-all"
        >
          <Trash2 size={18} />
          Clear All App Data
        </button>
      </section>
    </div>
  );
};
